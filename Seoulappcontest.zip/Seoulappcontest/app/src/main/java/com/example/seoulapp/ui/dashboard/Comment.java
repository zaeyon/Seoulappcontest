package com.example.seoulapp.ui.dashboard;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import com.example.seoulapp.R;

public class Comment extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comment);
    }
}
