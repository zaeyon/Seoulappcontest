package com.example.seoulapp;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class QnAPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qn_apage);
    }
}
