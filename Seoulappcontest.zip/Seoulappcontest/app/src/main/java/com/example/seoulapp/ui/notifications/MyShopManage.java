package com.example.seoulapp.ui.notifications;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.seoulapp.R;

public class MyShopManage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_shop_manage);
    }
}
