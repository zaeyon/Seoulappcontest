package com.example.seoulapp.ui.notifications;

public class NewsData {
  public String strNews;
}