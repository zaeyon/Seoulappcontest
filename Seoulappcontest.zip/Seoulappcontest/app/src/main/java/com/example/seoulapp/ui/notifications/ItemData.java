package com.example.seoulapp.ui.notifications;

public class ItemData {
  private String strShopName;
  private String strShopImage;

  public  String getStrShopName() {
    return strShopName;
  }
  public String getStrShopImage() { return strShopName; }

  public void setStrShopName(String shopName) { this.strShopName = shopName; }
  public void setStrShopImage(String image) {this.strShopImage = image;}
}