// MySQL DATABASE
module.exports = {
  host : 'localhost',
  user : 'root',
  password : '00000',
  port : 3306,
  database : 'test'

};